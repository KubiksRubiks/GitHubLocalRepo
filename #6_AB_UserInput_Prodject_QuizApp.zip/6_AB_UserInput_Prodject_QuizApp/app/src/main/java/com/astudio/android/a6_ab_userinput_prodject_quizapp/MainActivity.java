package com.astudio.android.a6_ab_userinput_prodject_quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    /**
     * The number of correct answers
     */
    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    /**
     * This method is called when the end quiz button is clicked.
     */
    public void endQuiz(View view) {
        EditText nameField = (EditText) findViewById(R.id.name_editText);
        String name = nameField.getText().toString();

        //Called question checking methods
        question_1();
        question_2();
        question_3();
        question_4();
        question_5();
        question_6();
        question_7();

        // Display the quiz result on the screen
        String quizResult = createQuizResult(name, score);
        displayResult(quizResult);

        // Disabled "End Quiz" button after clicking on it.
        Button endQuizButton = (Button) findViewById(R.id.end_quiz_button);
        endQuizButton.setEnabled(false);
    }

    /**
     * Create summary of the quiz result.
     *
     * @param name  of the passing the quiz
     * @param score of the counting of right answers
     * @return text of the quiz result
     */
    private String createQuizResult(String name, int score) {
        String quizResult = getString(R.string.quiz_result_name) + name;
        quizResult += "\n" + getString(R.string.quiz_result_score) + score;
        return quizResult;
    }

    /**
     * This method counter correct answers in question 1
     */
    public void question_1() {
        RadioButton answerRadioButton = (RadioButton) findViewById(R.id.answer_1_4_radio_button);
        boolean hasChecked = answerRadioButton.isChecked();

        if (hasChecked) {
            score++;
        }
    }

    /**
     * This method counter correct answers in question 2
     */
    public void question_2() {
        RadioButton answerRadioButton = (RadioButton) findViewById(R.id.answer_2_3_radio_button);
        boolean hasChecked = answerRadioButton.isChecked();

        if (hasChecked) {
            score++;
        }
    }

    /**
     * This method counter correct answers in question 3
     */
    public void question_3() {
        RadioButton answerRadioButton = (RadioButton) findViewById(R.id.answer_3_3_radio_button);
        boolean hasChecked = answerRadioButton.isChecked();

        if (hasChecked) {
            score++;
        }
    }

    /**
     * This method counter correct answers in question 4
     */
    public void question_4() {
        RadioButton answerRadioButton = (RadioButton) findViewById(R.id.answer_4_2_radio_button);
        boolean hasChecked = answerRadioButton.isChecked();

        if (hasChecked) {
            score++;
        }
    }

    /**
     * This method counter correct answers in question 5
     */
    public void question_5() {
        // Figure out if the user chose answer_5_2
        CheckBox answer_2_CheckBox = (CheckBox) findViewById(R.id.answer_5_2_check_box);
        boolean hasChecked_2 = answer_2_CheckBox.isChecked();

        if (hasChecked_2) {
            score++;
        }

        // Figure out if the user chose answer_5_3
        CheckBox answer_3_CheckBox = (CheckBox) findViewById(R.id.answer_5_3_check_box);
        boolean hasChecked_3 = answer_3_CheckBox.isChecked();

        if (hasChecked_3) {
            score++;
        }

        // Figure out if the user chose answer_5_5
        CheckBox answer_5_CheckBox = (CheckBox) findViewById(R.id.answer_5_5_check_box);
        boolean hasChecked_5 = answer_5_CheckBox.isChecked();

        if (hasChecked_5) {
            score++;
        }
    }

    /**
     * This method counter correct answers in question 6
     */
    public void question_6() {
        // Figure out if the user chose answer_6_1
        CheckBox answer_1_CheckBox = (CheckBox) findViewById(R.id.answer_6_1_check_box);
        boolean hasChecked_1 = answer_1_CheckBox.isChecked();

        if (hasChecked_1) {
            score++;
        }

        // Figure out if the user chose answer_6_3
        CheckBox answer_3_CheckBox = (CheckBox) findViewById(R.id.answer_6_3_check_box);
        boolean hasChecked_3 = answer_3_CheckBox.isChecked();

        if (hasChecked_3) {
            score++;
        }

        // Figure out if the user chose answer_6_4
        CheckBox answer_4_CheckBox = (CheckBox) findViewById(R.id.answer_6_4_check_box);
        boolean hasChecked_4 = answer_4_CheckBox.isChecked();

        if (hasChecked_4) {
            score++;
        }
    }

    /**
     * This method counter correct answers in question 7
     */
    public void question_7() {
        EditText editText = (EditText) findViewById(R.id.answer_edit_text);

        if (editText.getText().toString().equals(R.string.answer_7)) {
            score++;
        }
    }

    /**
     * This method displays the given text on the screen.
     */
    private void displayResult(String result) {
        TextView quizResultTextView = (TextView) findViewById(R.id.quiz_result_text_view);
        quizResultTextView.setText(result);
    }
}
